﻿# tankibrain

AI 资讯自动聚合站 — 定时抓取各大 AI 新闻源，提供简洁的个人资讯页面。

## 快速开始

### 1. 抓取最新 AI 资讯

`powershell
python scripts/fetch_news.py
`

这将从配置的数据源抓取最新 AI 资讯，生成 src/data.json。

### 2. 启动网站

`powershell
cd src
python -m http.server 8765
`

然后在浏览器打开 http://localhost:8765

### 3. 配置数据源

编辑 config/sources.json 添加/修改/删除数据源：

- 
ame: 源名称
- 	ype: ss (RSS/Atom 订阅) 或 hn (Hacker News)
- url: 数据源地址
- category: 分类 (Official/Research/Community/Chinese)
- lang: en / zh

## 数据源

| 源 | 类型 | 分类 | 语言 |
|---|---|---|---|
| OpenAI Blog | RSS | Official | en |
| Google AI | RSS | Official | en |
| Hacker News (AI) | HN | Community | en |
| 36氪 AI | RSS | Chinese | zh |
| 量子位 | RSS | Chinese | zh |

## 功能

- 深色主题设计，适配移动端
- 按分类筛选 (全部/官方/研究/社区/中文)
- 全文搜索 (标题+摘要+来源)
- 时间排序，自动显示相对时间
- 零依赖前端，纯静态 HTML+JS

## 定时更新

可以使用 Windows 任务计划程序或 cron 定期运行抓取脚本：

`powershell
# 每天自动抓取 (示例)
schtasks /create /tn "tankibrain_fetch" /tr "python scripts/fetch_news.py" /sc daily /st 08:00
`

## 部署到 tankibrain.com

1. 将 src/ 目录下的 index.html 和 data.json 部署到任意静态托管服务
2. 配置定时任务定期运行 scripts/fetch_news.py 更新数据
3. 推荐托管方案: Vercel, Netlify, GitHub Pages, 或自建 Nginx
