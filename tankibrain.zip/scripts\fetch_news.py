#!/usr/bin/env python3
"""
tankibrain news fetcher - 抓取 AI 消息源,输出 data.json
零第三方依赖,仅使用 Python 标准库。
"""

import json
import time
import re
import sys
import gzip
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "sources.json"
OUTPUT_PATH = PROJECT_ROOT / "src" / "data.json"


def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def clean_html(text):
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > 300:
        text = text[:297] + "..."
    return text


def parse_date(date_str):
    if not date_str:
        return None, 0
    formats = [
        "%a, %d %b %Y %H:%M:%S %Z",
        "%a, %d %b %Y %H:%M:%S %z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%d %H:%M:%S",
    ]
    for fmt in formats:
        try:
            dt = datetime.strptime(date_str.strip(), fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.isoformat(), int(dt.timestamp())
        except (ValueError, TypeError):
            continue
    return None, 0


def http_get(url, timeout, user_agent):
    req = Request(url, headers={
        "User-Agent": user_agent,
        "Accept": "application/rss+xml, application/xml, application/json, text/xml, */*",
        "Accept-Encoding": "gzip",
    })
    with urlopen(req, timeout=timeout) as resp:
        data = resp.read()
        if resp.headers.get("Content-Encoding") == "gzip":
            data = gzip.decompress(data)
        charset = "utf-8"
        ctype = resp.headers.get("Content-Type", "")
        m = re.search(r"charset=([\w-]+)", ctype)
        if m:
            charset = m.group(1)
        return data.decode(charset, errors="replace")


def fetch_rss(source, settings):
    items = []
    try:
        content = http_get(source["url"], settings["request_timeout"], settings["user_agent"])
    except Exception as e:
        print(f"  [WARN] {source['name']}: {e}")
        return items

    item_blocks = re.findall(r"<item[^>]*>(.*?)</item>", content, re.DOTALL)
    if not item_blocks:
        item_blocks = re.findall(r"<entry[^>]*>(.*?)</entry>", content, re.DOTALL)

    for block in item_blocks[:settings["max_items_per_source"]]:
        title = ""
        link = ""
        desc = ""
        date_str = ""

        title_m = re.search(r"<title[^>]*>(.*?)</title>", block, re.DOTALL)
        if title_m:
            title = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", title_m.group(1)).strip()
            title = re.sub(r"&amp;", "&", title)

        link_m = re.search(r"<link[^>]*>(.*?)</link>", block, re.DOTALL)
        if link_m and link_m.group(1).strip():
            link = link_m.group(1).strip()
        else:
            link_m = re.search(r'<link[^>]*href="([^"]+)"', block)
            if link_m:
                link = link_m.group(1).strip()

        desc_m = re.search(r"<description[^>]*>(.*?)</description>", block, re.DOTALL)
        if not desc_m:
            desc_m = re.search(r"<summary[^>]*>(.*?)</summary>", block, re.DOTALL)
        if desc_m:
            raw = re.sub(r"<!\[CDATA\[(.*?)\]\]>", r"\1", desc_m.group(1))
            desc = clean_html(raw)

        date_m = re.search(r"<pubDate[^>]*>(.*?)</pubDate>", block, re.DOTALL)
        if not date_m:
            date_m = re.search(r"<published[^>]*>(.*?)</published>", block, re.DOTALL)
        if not date_m:
            date_m = re.search(r"<updated[^>]*>(.*?)</updated>", block, re.DOTALL)
        if date_m:
            date_str = date_m.group(1).strip()

        iso_date, ts = parse_date(date_str)
        if title and link:
            items.append({
                "title": title, "link": link, "summary": desc,
                "date": iso_date, "timestamp": ts,
                "source_id": source["id"], "source_name": source["name"],
                "category": source["category"], "lang": source["lang"],
            })
    print(f"  [OK] {source['name']}: {len(items)}")
    return items


def fetch_hn(source, settings):
    items = []
    try:
        content = http_get(source["url"], settings["request_timeout"], settings["user_agent"])
        data = json.loads(content)
    except Exception as e:
        print(f"  [WARN] {source['name']}: {e}")
        return items

    hits = data.get("hits", [])[:settings["max_items_per_source"] * 3]
    for hit in hits:
        title = hit.get("title") or hit.get("story_title") or ""
        if not title:
            continue
        link = hit.get("url") or f"https://news.ycombinator.com/item?id={hit.get('objectID', '')}"
        ts = hit.get("created_at_i", 0)
        iso_date = datetime.fromtimestamp(ts, tz=timezone.utc).isoformat() if ts else None
        text_blob = f"{title} {hit.get('story_text', '')}".lower()
        ai_kw = ["ai","artificial intelligence","machine learning","ml","llm","gpt",
                 "neural","deep learning","transformer","openai","anthropic","claude","gemini","diffusion"]
        if not any(k in text_blob for k in ai_kw):
            continue
        items.append({
            "title": title, "link": link, "summary": clean_html(hit.get("story_text", "")),
            "date": iso_date, "timestamp": ts,
            "source_id": source["id"], "source_name": source["name"],
            "category": source["category"], "lang": source["lang"],
            "points": hit.get("points", 0),
        })
    items = items[:settings["max_items_per_source"]]
    print(f"  [OK] {source['name']}: {len(items)}")
    return items


def main():
    print("=" * 50)
    print("tankibrain news fetcher")
    print("=" * 50)
    config = load_config()
    sources = config["sources"]
    settings = config["settings"]
    all_items = []
    for source in sources:
        print(f"\n[{source['name']}] fetching...")
        try:
            if source["type"] == "rss":
                items = fetch_rss(source, settings)
            elif source["type"] == "hn":
                items = fetch_hn(source, settings)
            else:
                print(f"  [SKIP] unknown type: {source['type']}")
                continue
            all_items.extend(items)
        except Exception as e:
            print(f"  [ERROR] {source['name']}: {e}")
        time.sleep(0.5)

    all_items.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
    output = {
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "total_count": len(all_items),
        "sources_count": len(sources),
        "items": all_items,
    }
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"\n{'=' * 50}")
    print(f"Done! {len(all_items)} items")
    print(f"Output: {OUTPUT_PATH}")
    print(f"{'=' * 50}")


if __name__ == "__main__":
    main()
